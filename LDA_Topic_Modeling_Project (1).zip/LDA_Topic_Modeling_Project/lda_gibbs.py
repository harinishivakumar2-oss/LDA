"""
Small collapsed-Gibbs-sampling demonstration for LDA.
Run: python lda_gibbs.py
This uses a tiny built-in corpus and prints the most frequent words per sampled topic.
For a larger real project, use the Streamlit app (scikit-learn variational Bayes).
"""
import re
import random
from collections import Counter, defaultdict

random.seed(7)
docs = [
    "football team goal match coach player training",
    "basketball team player game score championship",
    "soccer goal fans player match victory",
    "doctor hospital patient medicine health treatment",
    "health medicine disease doctor patient research",
    "exercise healthy food sleep health treatment",
    "python software computer code machine learning",
    "artificial intelligence model data algorithm computer",
    "database software system code user application",
    "student teacher university classroom exam learning",
    "education student course lesson assignment teacher",
    "online course student study university exam",
    "company sales market product profit business",
    "stock investor finance company revenue market",
    "marketing customer product sales business campaign",
]
K = 4
ITERATIONS = 100
ALPHA = 0.1
BETA = 0.01

def tokenize(text):
    return re.findall(r"[a-z]+", text.lower())

tokens_by_doc = [tokenize(d) for d in docs]
vocab = sorted({w for doc in tokens_by_doc for w in doc})
word_to_id = {w: i for i, w in enumerate(vocab)}
V = len(vocab)
doc_topic = [Counter() for _ in docs]
topic_word = [Counter() for _ in range(K)]
topic_totals = [0] * K
assignments = []

# Randomly initialise one topic per token.
for d, words in enumerate(tokens_by_doc):
    row = []
    for word in words:
        w = word_to_id[word]
        z = random.randrange(K)
        row.append(z)
        doc_topic[d][z] += 1
        topic_word[z][w] += 1
        topic_totals[z] += 1
    assignments.append(row)

for _ in range(ITERATIONS):
    for d, words in enumerate(tokens_by_doc):
        for i, word in enumerate(words):
            w = word_to_id[word]
            old_z = assignments[d][i]
            doc_topic[d][old_z] -= 1
            topic_word[old_z][w] -= 1
            topic_totals[old_z] -= 1

            weights = []
            for k in range(K):
                left = doc_topic[d][k] + ALPHA
                right = (topic_word[k][w] + BETA) / (topic_totals[k] + V * BETA)
                weights.append(left * right)
            total = sum(weights)
            r = random.random() * total
            cumulative = 0.0
            new_z = K - 1
            for k, weight in enumerate(weights):
                cumulative += weight
                if r <= cumulative:
                    new_z = k
                    break

            assignments[d][i] = new_z
            doc_topic[d][new_z] += 1
            topic_word[new_z][w] += 1
            topic_totals[new_z] += 1

print("Collapsed Gibbs sampling results")
print(f"Documents={len(docs)}, vocabulary={V}, topics={K}, iterations={ITERATIONS}\n")
for k in range(K):
    most_common = topic_word[k].most_common(8)
    words = [vocab[w] for w, count in most_common if count > 0]
    print(f"Topic {k+1}: {', '.join(words) if words else '(no words assigned)'}")
print("\nInterpretation: group the top words in each topic into a human-readable theme.")
