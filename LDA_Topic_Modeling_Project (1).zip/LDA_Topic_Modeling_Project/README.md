# LDA Topic Modeling Project

## Goal
Apply Latent Dirichlet Allocation (LDA) to a collection of documents and interpret the topics using probabilistic and sampling-based methods.

## Features
- Built-in document collection covering sports, healthcare, technology, education, and business.
- Streamlit interface for training LDA and viewing top words per topic.
- Document-topic probability table and CSV export.
- `lda_gibbs.py` demonstrates collapsed Gibbs sampling.

## Run in VS Code (about 10 minutes)
1. Install Python 3.10 or newer and VS Code.
2. Extract this ZIP and open the `LDA_Topic_Modeling_Project` folder in VS Code.
3. Open Terminal > New Terminal.
4. Create and activate a virtual environment (optional but recommended):

   **Windows**
   ```powershell
   python -m venv .venv
   .venv\\Scripts\\activate
   ```

5. Install dependencies:
   ```powershell
   pip install -r requirements.txt
   ```
6. Start the app:
   ```powershell
   streamlit run app.py
   ```
7. A browser tab opens. Click **Discover topics**. Try 3–5 topics and inspect the topic words and document probabilities.
8. To show the sampling-based method in the terminal, run:
   ```powershell
   python lda_gibbs.py
   ```

## What to explain in a demo
- **LDA:** a document is a mixture of topics; a topic is a probability distribution over words.
- **Probabilistic method:** the Streamlit app uses scikit-learn's batch variational-Bayes inference to estimate document-topic and topic-word distributions.
- **Sampling-based method:** `lda_gibbs.py` uses collapsed Gibbs sampling. For each token, it removes its current assignment and samples a new topic using document-topic and topic-word counts with smoothing parameters alpha and beta.
- **Interpretation:** inspect the highest-weight words in each topic and give the topic a human label such as Sports, Healthcare, Technology, Education, or Business. The exact ordering and word grouping can vary.
- **Limitation:** this is a small demonstration dataset; use a larger, domain-specific corpus for stronger results.

## Upload your own collection
Prepare a CSV file with a column named `text`, one document per row. Upload it from the app page.
