import re
import pandas as pd
import streamlit as st
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation

st.set_page_config(page_title="LDA Topic Discovery", page_icon="📚", layout="wide")
st.title("Latent Dirichlet Allocation (LDA) Topic Discovery")
st.write("Upload a CSV with a **text** column, or use the built-in sample collection. LDA estimates topic-word and document-topic probabilities.")

SAMPLE_DOCS = [
    "The team won the football match after scoring two goals. The coach praised the players and training.",
    "The basketball team practiced shooting and defense before the championship game.",
    "The player scored a goal in the soccer final and fans celebrated the victory.",
    "Doctors treated patients at the hospital using medical tests and new treatments.",
    "Researchers studied disease symptoms and tested a medicine in a clinical trial.",
    "Healthy food, exercise, sleep, and regular checkups can improve physical health.",
    "The software developer wrote Python code to build a machine learning application.",
    "Artificial intelligence models learn patterns from data using algorithms and neural networks.",
    "The computer system stores information in a database and processes user requests.",
    "Students studied for exams in the university library and completed their assignments.",
    "The teacher explained mathematics and science lessons to students in the classroom.",
    "Online education courses help learners practice skills and submit assignments.",
    "The company reported higher sales and profit after launching a new product.",
    "Investors reviewed the stock market, business revenue, and financial performance.",
    "The marketing team advertised products to customers through digital campaigns.",
]

with st.sidebar:
    st.header("Model settings")
    n_topics = st.slider("Number of topics", 2, 8, 4)
    n_words = st.slider("Top words per topic", 3, 12, 7)
    max_features = st.slider("Vocabulary size", 500, 3000, 1500, step=500)
    max_iter = st.slider("Training iterations", 5, 30, 15, step=5)
    random_state = st.number_input("Random seed", min_value=0, max_value=9999, value=42)

uploaded = st.file_uploader("Optional: upload a CSV containing a column named 'text'", type=["csv"])
if uploaded:
    try:
        df = pd.read_csv(uploaded)
        if "text" not in df.columns:
            st.error("The CSV needs a column named 'text'.")
            st.stop()
        documents = df["text"].dropna().astype(str).tolist()
    except Exception as e:
        st.error(f"Could not read CSV: {e}")
        st.stop()
else:
    documents = SAMPLE_DOCS
    st.info("Using 15 built-in sample documents about sports, healthcare, technology, education, and business.")

st.subheader("Document collection")
st.write(f"Documents available: **{len(documents)}**")
with st.expander("Preview documents"):
    st.dataframe(pd.DataFrame({"text": documents}), use_container_width=True)

if st.button("Discover topics", type="primary"):
    if len(documents) < 2:
        st.error("Please provide at least two documents.")
        st.stop()
    vectorizer = CountVectorizer(stop_words="english", max_features=max_features, max_df=1.0, min_df=1)
    try:
        X = vectorizer.fit_transform(documents)
    except ValueError:
        st.error("Not enough usable words. Add longer documents.")
        st.stop()
    if X.shape[1] < n_topics:
        st.warning("Vocabulary is small; try fewer topics or add more text.")
    model = LatentDirichletAllocation(
        n_components=n_topics, max_iter=max_iter, learning_method="batch",
        random_state=int(random_state), doc_topic_prior=0.1, topic_word_prior=0.01
    )
    with st.spinner("Training probabilistic topic model..."):
        doc_topic = model.fit_transform(X)
    terms = vectorizer.get_feature_names_out()
    st.success(f"Finished: {X.shape[0]} documents, {X.shape[1]} vocabulary terms, {n_topics} topics.")
    st.subheader("1. Discovered topics")
    topic_rows = []
    for k, weights in enumerate(model.components_):
        top_idx = weights.argsort()[-n_words:][::-1]
        top_terms = [terms[i] for i in top_idx]
        probs = weights[top_idx] / weights.sum()
        topic_rows.append({"Topic": f"Topic {k+1}", "Top words": ", ".join(top_terms),
                           "Approx. probability mass of displayed words": round(float(probs.sum()), 3)})
    st.dataframe(pd.DataFrame(topic_rows), use_container_width=True)
    st.caption("Interpret the topic from its highest-weight words. Topic labels are human interpretations, not automatically known categories.")
    st.subheader("2. Document-topic probabilities")
    result = pd.DataFrame(doc_topic, columns=[f"Topic {i+1}" for i in range(n_topics)])
    result.insert(0, "Document", [f"Document {i+1}" for i in range(len(documents))])
    result["Dominant topic"] = result.iloc[:, 1:1+n_topics].idxmax(axis=1)
    st.dataframe(result.round(3), use_container_width=True)
    st.subheader("3. Interpretation")
    for i in range(n_topics):
        st.write(f"**Topic {i+1}:** strongest in {', '.join(topic_rows[i]['Top words'].split(', ')[:4])}. Read the top words together to assign a meaningful theme.")
    st.subheader("4. Probabilistic method")
    st.write("LDA treats each document as a mixture of topics and each topic as a probability distribution over words. This implementation uses scikit-learn's batch variational-Bayes inference to estimate these distributions.")
    st.subheader("5. Sampling-based method")
    st.write("A common alternative is collapsed Gibbs sampling: repeatedly sample a topic assignment for each token using the counts of topics in its document and words in each topic. The included `lda_gibbs.py` demonstrates this sampling-based approach.")
    st.download_button("Download document-topic probabilities (CSV)", result.to_csv(index=False).encode("utf-8"), "document_topic_probabilities.csv", "text/csv")
